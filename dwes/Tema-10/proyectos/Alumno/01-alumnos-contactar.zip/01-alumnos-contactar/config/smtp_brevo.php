<?php

    /*
        Configuración acceso servidor SMTP brevo
    */

    // Host smtp brevo
    define('SMTP_HOST', 'smtp-relay.brevo.com');

    // Puerto smtp brevo
    define('SMTP_PORT', 587);

    // Usuario smtp brevo
    define('SMTP_USER', 'nerom24@gmail.com');

    // Contraseña smtp brevo
    define('SMTP_PASS', '******************');