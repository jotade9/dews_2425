<?php
# Configuración básica aplicación MVC

# Ruta absoluta

define('URL', 'http://localhost/dwes_2425/tema-10/proyectos/01-alumnos-contactar/');

# Constante de la Base de Datos
define('HOST', 'localhost');
define('DB', 'fp');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');


?>