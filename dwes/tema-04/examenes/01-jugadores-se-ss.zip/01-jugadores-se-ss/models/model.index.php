<?php

    /*
        Modelo: model.index.php
        Descripción: genera array objetos de la clase jugadores
    */

    


