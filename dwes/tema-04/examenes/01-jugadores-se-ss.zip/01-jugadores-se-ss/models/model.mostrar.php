<?php

    /*
        modelo: model.mostrar.php
        descripción: carga los datos del jugador que deseo mostrar

        Método GET:

            - indice de la tabla en la que se encuentra el jugador
    */

