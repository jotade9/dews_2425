<?php
    /*
        autor: model.create.php
        descripción: añade el nuevo jugador a la tabla
        
        Métod POST:
            
    */
