<?php

    /*
        controlador: index.php
        descripción: muestra los detalles de los libros
    */

    