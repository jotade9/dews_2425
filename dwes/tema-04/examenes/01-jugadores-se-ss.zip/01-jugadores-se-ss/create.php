<?php

    /*
        controlador: create.php
        descripción: añade nuevo jugador a la tabla
    */
