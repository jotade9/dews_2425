<?php

/*
    clase: class.tabla_jugadores.php
    descripcion: define la clase que va a contener el array de objetos de la clase jugadores.
*/

