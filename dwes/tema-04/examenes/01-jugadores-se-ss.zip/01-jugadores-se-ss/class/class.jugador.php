<?php

    /*
        archivo:class.jugador.php
        nombre: define la clase jugador sin encapsulamiento
    */


