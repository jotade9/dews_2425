<?php

/*
        controlador: nuevo.php
        descripción: muestra formulario añadir jugador
    */

    