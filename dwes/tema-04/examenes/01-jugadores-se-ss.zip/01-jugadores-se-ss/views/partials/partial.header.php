<!-- Cabecera del documento -->
<header class="pb-3 mb-4 border-bottom">
        <span class="fs-5">
            <i class="bi bi-trophy-fill"></i>
            Examen 4.1 Gestión Jugadores S.E.
        </span>
</header>