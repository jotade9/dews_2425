<!DOCTYPE html>
<html lang="es">
<head>
    <!-- incluye head -->
    <title>Gestión de jugadores - Home </title>
</head>
<body>
    <!-- Capa Principal -->
    <div class="container">

        <!-- Encabezado proyecto -->
        <!-- incluye header -->

                
        <!-- Menú principal -->
        <!-- incluye menú principal -->
       
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <!-- Mostramos el encabezado de la tabla -->
                    <tr>
                        <th>Id</th>
                        <th>Nombre</th>
                        <th>Equipo</th>
                        <th>Nacionalidad</th>
                        <th>Posiciones</th>
                        <th class='text-end'>Edad</th>
                        <th class='text-end'>Altura</th>
                        <th class='text-end'>Peso</th>
                        <th class='text-end'>Valor</th>
                        
                        <!-- columna de acciones -->
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Mostramos cuerpo de la tabla -->
                        <tr>
                            <!-- Mostramos detalles del jugador -->
                            
                            <!-- Columna de acciones -->
                            <td>
                            <div class="btn-group btn-group-toggle" data-toggle="buttons">
                                <a href="#" title="Eliminar" class="btn btn-danger" onclick="return confirm('Confimar elimación del jugador')"><i class="bi bi-trash-fill"></i></a>
                                <a href="#" title="Editar" class="btn btn-primary"><i class="bi bi-pencil-square"></i></a>
                                <a href="#" title="Mostrar" class="btn btn-warning"><i class="bi bi-eye-fill"></i></a>
                            </div>
                            </td>
                        </tr>
                   
                </tbody>
                <tfoot>
                    <tr><td colspan="6">Nº Registros</td></tr>
                </tfoot>
            </table>
        </div>
    </div>
    <br><br><br>

    <!-- Pie del documento -->
     <!-- inclye footer -->
   
    <!-- Bootstrap Javascript y popper -->
    <!-- incluye javascript -->
    
 
</body>
</html>