<?php

    /*

        Modelo: model.index.php
        Descripción: muestra los detalles de los artículos
    */

    

?>