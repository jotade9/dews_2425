<!DOCTYPE html>
<html lang="es">
<head>
    <!-- cargar head.html -->
    <title>Gestión de Artículos - Home </title>
</head>
<body>
    <!-- Capa Principal -->
    <div class="container">

        <!-- Encabezado proyecto -->
        <!-- cargar partial.header.php -->

                
        <!-- Menú principal -->
        <!-- cargar partial.menu.php -->
       
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <!-- Mostramos el encabezado de la tabla -->
                    
                </thead>
                <tbody>
                    <!-- Mostramos cuerpo de la tabla -->
                      
                </tbody>
                <tfoot>
                    <!-- Mostrar el número de registros de la tabla -->
                </tfoot>
            </table>
        </div>
    </div>
    <br><br><br>

    <!-- Pie del documento -->
    <!-- cargar partial.footer.php -->

    <!-- Bootstrap Javascript y popper -->
    <!-- cargar javascript.php -->
    
 
</body>
</html>