<!-- Cabecera del documento -->
<header class="pb-3 mb-4 border-bottom">
        <span class="fs-5">
            <i class="bi bi-bag-dash-fill"></i>
            Panel de Control - Artículos 
        </span>
</header>