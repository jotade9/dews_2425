<?php

    /*
        Controlador: nuevo.php
        Descripcion: muestra formulario añadir nuevo artículo
    */

   

?>