<?php
    /*
        Controlador: index.php
        Descripción: controlador principal proyecto artículos
    */
    

?>